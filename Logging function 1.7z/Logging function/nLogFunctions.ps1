﻿function global:Get-FunctionName ([int]$StackNumber = 1) {return [string]$(Get-PSCallStack)[$StackNumber].FunctionName}

function global:Get-Logger() {
	
	$method = Get-FunctionName -StackNumber 2

	$logCfg						= Get-NewLogConfig
	
	$debugLog 					= Get-NewLogTarget -targetType "file"
	$debugLog.archiveEvery 		= "Day"
	$debugLog.ArchiveNumbering 	= "Rolling"	
	$debugLog.CreateDirs		= $true	
	$debugLog.FileName 			= 'C:\ConnectorLogs\Navision\Powershell\log\Navision.log'
	$debugLog.Encoding 			= [System.Text.Encoding]::GetEncoding("utf-8")
	$debugLog.KeepFileOpen 		= $false
	$debugLog.Layout 			= Get-LogMessageLayout -layoutId 3 -method $method
	$debugLog.maxArchiveFiles 	= 31
    $debugLog.archiveFileName   = 'C:\ConnectorLogs\Navision\Powershell\Archives\Navision.{#}.log'
	$logCfg.AddTarget("file", $debugLog)
	
	$console 					= Get-NewLogTarget -targetType "console"
	$console.Layout 			= Get-LogMessageLayout -layoutId 3 -method $method
	$logCfg.AddTarget("console", $console)
	
	$rule1 = New-Object NLog.Config.LoggingRule("*", [NLog.LogLevel]::Trace, $console)
	$logCfg.LoggingRules.Add($rule1)
	
	$rule2 = New-Object NLog.Config.LoggingRule("*", [NLog.LogLevel]::Info, $debugLog)
	$logCfg.LoggingRules.Add($rule2)
	
	[NLog.LogManager]::Configuration = $logCfg

	$Log = Get-NewLogger -loggerName "Logger"
    
    return $Log
}

function global:Get-NewLogger() {
    param ( 
		[parameter(mandatory=$true)] 
		[System.String]$loggerName 
	) 
    
    [NLog.LogManager]::GetLogger($loggerName) 
}


function global:Get-NewLogConfig() {
	New-Object NLog.Config.LoggingConfiguration 
}


function global:Get-NewLogTarget() {
	param ( 
		[parameter(mandatory=$true)] 
		[System.String]$targetType 
	) 
	
	switch ($targetType) {
		"console" {
			New-Object NLog.Targets.ColoredConsoleTarget	
		}
		"file" {
			New-Object NLog.Targets.FileTarget
		}
		"mail" { 
			New-Object NLog.Targets.MailTarget
		}
	}

}


function global:Get-LogMessageLayout() {
	param ( 
        [parameter(mandatory=$true)] 
        [System.Int32]$layoutId,
        [parameter(mandatory=$false)] 
        [String]$method 
    ) 
	
	switch ($layoutId) {
		1 {
			$layout	= '${longdate} | ${machinename} | ${processid} | ${processname} | ${level} | ${logger} | ${message}'
		}
		2 {
			$layout	= '${longdate} | ${machinename} | ${processid} | ${processname} | ${level} | ${logger} | ${message}'
		}
        3 {
			$layout	= '${longdate} [${level}] (${processid}) ' + $($method) + ' ${message}'
		}
	}
	return $layout
}