To get the logger to work properly just copy/paste the contents of nLogFunctions.ps1, or follow (carefully) the following steps and declare the objects, properties etc. 
Otherwise it could lead to a script malfunction!

STEPS:
**This step is mandatory**
1. Include the following line at the top of your script and make sure to use the absolut path
	[System.Reflection.Assembly]::LoadFile("YOUR_PATH\NLog.dll")

****The following steps are only necessary if you write the logging function from scratch, otherwise you can copy/paste the contents of nLogFunctions.ps1
to you script and only adjust what is needed.*****

2. Create a LogConfig object

3. Create and configure a LogTarget (Repeat this step, as much as, how many targets you need)

4. Create a LoggingRule in the current LogConfig for each target

5. Assign the LogConfig to the LogManager Configuration

6. Create the Logger instance

7. Start implement log messages to your script


The TestScript.ps1 shows you, how to use the NLog-PowerShell Interface. 
All the important parts; how to instantiate a new logger, log targets, log config and logging rules, are located in the Function Test-ScriptLogger().
A more real-life example can be found in HowToUseIt(example).ps1

USEFUL LINKS:

1. https://12.mayjestic.net/ms/powershell-logging-interface/ (source)
2. https://github.com/nlog/nlog/wiki
3. https://github.com/NLog/NLog/wiki/File-target#archive-old-log-files
4. https://github.com/NLog/NLog/wiki/FileTarget-Archive-Examples
5. https://www.codeproject.com/Articles/4051307/NLog-Rules-and-filters