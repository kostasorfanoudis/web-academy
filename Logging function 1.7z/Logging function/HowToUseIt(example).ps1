﻿#Make sure to add the absolut path. Relative path doen't work in this case
[System.Reflection.Assembly]::LoadFile("YOUR_PATH\NLog.dll")

function global:Get-AllCompanies {

param(
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String]$Username,
    
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String]$PWD
  
)
    #Initalize Logger
    $Log = Get-Logger

    $Password = $PWD | ConvertTo-SecureString -AsPlainText -Force
    [pscredential]$credObject = New-Object System.Management.Automation.PSCredential ($Username, $Password)
    $URI = "http://molbudanav03t.mol.sys.corp:26057/MOL-TEST-FIN/WS/1003_Geoinform/Page/IDM_Companies"

    #Write-Log -Level INFO -Message "START"
    $Log.Info("START")

    try{

        $ReturnedData = [System.Collections.ArrayList]@() 

        #Write-Log -Level DEBUG -Message "Fetching data for all companies..."
        $Log.Debug("Fetching data for all companies...")

            
        [xml] $Body = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:idm="urn:microsoft-dynamics-schemas/page/idm_companies">
                           <soapenv:Header/>
                           <soapenv:Body>
                              <idm:ReadMultiple>
                                 <!--1 or more repetitions:-->
                                 <idm:filter>
                                    <idm:Field></idm:Field>
                                    <idm:Criteria></idm:Criteria>
                                 </idm:filter>
                                 <!--Optional:-->
                                 <idm:bookmarkKey></idm:bookmarkKey>
                                 <idm:setSize></idm:setSize>
                              </idm:ReadMultiple>
                           </soapenv:Body>
                        </soapenv:Envelope>'

        $headers=@{}
        $headers.Add("SOAPAction","urn:microsoft-dynamics-schemas/page/idm_companies:ReadMultiple")
        $headers.Add("Content-Type", "text/xml;charset=UTF-8")


        [xml]$Companies = Invoke-WebRequest -Credential $credObject -Uri $URI  -Method Post -Body $Body -ContentType text/xml -Headers $headers
            
        #Write-Log -Level DEBUG -Message "Collecting all companies"
        $Log.Debug("Collecting all companies")
  

        ForEach($Company in $Companies.Envelope.Body.ReadMultiple_Result.ReadMultiple_Result.IDM_Companies){

            $Row =  [PSCustomObject] @{
                Company = $Company.Name
            }
        
            [void]$ReturnedData.Add($Row)
        }

 

    }catch{
        #Write-Log -Level ERROR -Message "'$($_)'"
        $Log.Error("'$($_)'")
        throw ($_.Exception.Message)
    }

    #Write-Log -Level INFO -Message "Successfully fetched all companies"
    $Log.Debug("Successfully fetched all companies")

    #Write-Log -Level INFO -Message "END"
    $Log.Info("END")

    return $ReturnedData 

}

function global:Get-FunctionName ([int]$StackNumber = 1) {return [string]$(Get-PSCallStack)[$StackNumber].FunctionName}

function global:Get-Logger() {
	
	$method = Get-FunctionName -StackNumber 2

	$logCfg						= Get-NewLogConfig
	
	$debugLog 					= Get-NewLogTarget -targetType "file"
	$debugLog.archiveEvery 		= "Day"
	$debugLog.ArchiveNumbering 	= "Rolling"	
	$debugLog.CreateDirs		= $true	
	$debugLog.FileName 			= 'C:\ConnectorLogs\Navision\Powershell\log\Navision.log'
	$debugLog.Encoding 			= [System.Text.Encoding]::GetEncoding("utf-8")
	$debugLog.KeepFileOpen 		= $false
	$debugLog.Layout 			= Get-LogMessageLayout -layoutId 3 -method $method
	$debugLog.maxArchiveFiles 	= 31
    $debugLog.archiveFileName   = 'C:\ConnectorLogs\Navision\Powershell\Archives\Navision.{#}.log'
	$logCfg.AddTarget("file", $debugLog)
	
	$console 					= Get-NewLogTarget -targetType "console"
	$console.Layout 			= Get-LogMessageLayout -layoutId 3 -method $method
	$logCfg.AddTarget("console", $console)
	
	$rule1 = New-Object NLog.Config.LoggingRule("*", [NLog.LogLevel]::Trace, $console)
	$logCfg.LoggingRules.Add($rule1)
	
	$rule2 = New-Object NLog.Config.LoggingRule("*", [NLog.LogLevel]::Info, $debugLog)
	$logCfg.LoggingRules.Add($rule2)
	
	[NLog.LogManager]::Configuration = $logCfg

	$Log = Get-NewLogger -loggerName "Logger"
    
    return $Log
}

function global:Get-NewLogger() {
    param ( [parameter(mandatory=$true)] [System.String]$loggerName ) 
    
    [NLog.LogManager]::GetLogger($loggerName) 
}


function global:Get-NewLogConfig() {

	New-Object NLog.Config.LoggingConfiguration 
}


function global:Get-NewLogTarget() {
	param ( [parameter(mandatory=$true)] [System.String]$targetType ) 
	
	switch ($targetType) {
		"console" {
			New-Object NLog.Targets.ColoredConsoleTarget	
		}
		"file" {
			New-Object NLog.Targets.FileTarget
		}
		"mail" { 
			New-Object NLog.Targets.MailTarget
		}
	}

}


function global:Get-LogMessageLayout() {
	param ( 
        [parameter(mandatory=$true)] 
        [System.Int32]$layoutId,
        [parameter(mandatory=$false)] 
        [String]$method 
    ) 
	
	switch ($layoutId) {
		1 {
			$layout	= '${longdate} | ${machinename} | ${processid} | ${processname} | ${level} | ${logger} | ${message}'
		}
		2 {
			$layout	= '${longdate} | ${machinename} | ${processid} | ${processname} | ${level} | ${logger} | ${message}'
		}
        3 {
			$layout	= '${longdate} [${level}] (${processid}) ' + $($method) + ' ${message}'
		}
	}
	return $layout
}