<#
.SYNOPSIS
   A PowerShell CmdLet that add's logging functionality to your scripts
.DESCRIPTION
   The script is using the nLog .NET Library ( https://github.com/nlog/NLog | http://nlog-project.org )
   What gives you a couple of good logging features with a lot of control.
.EXAMPLE
   Look at the Test-ScriptLogger Function to see how the script works
#>

<# Include block #>
# ### !!! Adjust absolute path first
Write-Host " "
Write-Host "Loading external assembly"
[System.Reflection.Assembly]::LoadFile("C:\Users\user\Documents\MOL\nlog\NLog-PowerShell-Interface\LogInterface\lib\NLog.dll")

Write-Host " "

<# Function block #>

<#
.SYNOPSIS
	Creates a new LogManager instance
.DESCRIPTION
	Important to log messages to file, mail, console etc.
.EXAMPLE
   $myLogger = Get-NewLogger()
#>
function Get-NewLogger() {
    param ( [parameter(mandatory=$true)] [System.String]$loggerName ) 
    
    [NLog.LogManager]::GetLogger($loggerName) 
}


<#
.SYNOPSIS
	Creates a new configuration in memory
.DESCRIPTION
	Important to add logging behaviour and log targets to your LogManager
.EXAMPLE
   $myLogconfig = Get-NewLogConfig()
#>
function Get-NewLogConfig() {

	New-Object NLog.Config.LoggingConfiguration 
}


<#
.SYNOPSIS
	Creates a new logging target
.DESCRIPTION
	Logging targets are required to write down the log messages somewhere
.EXAMPLE
   $myFilelogtarget = Get-NewLogTarget -targetType "file"
#>
function Get-NewLogTarget() {
	param ( [parameter(mandatory=$true)] [System.String]$targetType ) 
	
	switch ($targetType) {
		"console" {
			New-Object NLog.Targets.ColoredConsoleTarget	
		}
		"file" {
			New-Object NLog.Targets.FileTarget
		}
		"mail" { 
			New-Object NLog.Targets.MailTarget
		}
	}

}

<#
.SYNOPSIS
	Sets the log message layout
.DESCRIPTION
	Defines, how your log message looks like. This function can be enhanced by yourself. I just provided a few examples how log messages can look like
.EXAMPLE
   #$myFilelogtarget.Layout	= Get-LogMessageLayout -layoutId 1
#>
function Get-LogMessageLayout() {
	param ( 
        [parameter(mandatory=$true)] 
        [System.Int32]$layoutId,
        [parameter(mandatory=$false)] 
        [String]$method 
    ) 
	
	switch ($layoutId) {
		1 {
			$layout	= '${longdate} | ${machinename} | ${processid} | ${processname} | ${level} | ${logger} | ${message}'
		}
		2 {
			$layout	= '${longdate} | ${machinename} | ${processid} | ${processname} | ${level} | ${logger} | ${message}'
		}
        3 {
			$layout	= '${longdate} [${level}] (${processid}) ' + $($method) + ' ${message}'
		}
	}
	return $layout
}
 ## Where $method --> function global:Get-FunctionName ([int]$StackNumber = 1) {return [string]$(Get-PSCallStack)[$StackNumber].FunctionName}

